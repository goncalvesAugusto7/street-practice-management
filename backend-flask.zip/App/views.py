from App import app
from flask import render_template, url_for

@app.route('/')
def homepage():
    context = {
        'userName' : "Augusto",
        'age' : 21
    }
    return render_template('index.html',context=context) 

@app.route('/newpage')
def newpage():
    return "This is a newpage baby!"