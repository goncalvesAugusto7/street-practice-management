from App import db

class Contato(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=True)
    email = db.Column(db.String, nullable=True)
    dateofbirth = db.Column(db.DateTime, nullable=True)
